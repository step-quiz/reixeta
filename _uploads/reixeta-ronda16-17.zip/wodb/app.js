/* Reixeta · WODB — pàgina d'impressió */
(function(){
'use strict';
const W=window.WODB,BANCS=window.BANCS,ORDRE=window.BANCS_ORDRE;
const $=s=>document.querySelector(s);
const {CEL,FORAT,MARGE,ITEM,MARC}=PLANTILLA.MIDES;   // mm: casella, forat, marge del forat, dibuix, marc de la plantilla (comu/plantilla.js, ronda 16)
const FIXOS=c=>Object.keys(BANCS[c].fulls);              // fulls fixos d'un banc: A, B, C, D
const generats={};               // 'NUM-4821' -> tauler
const st={banc:'NUM',ver:'A',vista:'full',model:'un',solu:new Set(ORDRE)};   // solu: temes (els 4 fulls fixos) i fulls generats triats
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function tauler(id){const [c,v]=id.split('-');return BANCS[c].fulls[v]||generats[id];}
/* ---------- full 1 ---------- */
function fullSVG(id){const [code]=id.split('-'),B=BANCS[code],T=tauler(id),[R,C]=W.dims(B);
  const w=C*CEL,h=R*CEL,x0=(297-w)/2,y0=(210-h)/2,it=B.caixa||ITEM;let o=`<svg class="full" viewBox="0 0 297 210" xmlns="http://www.w3.org/2000/svg">`;
  o+=`<text x="287" y="14" font-size="5.5" text-anchor="end" font-family="Courier New,monospace" font-weight="700">${id}</text>`;
  o+=PLANTILLA.guies(x0,y0,R,C,PLANTILLA.MIDES);   // guies als quatre costats, fora del marc de la plantilla
  for(let r=0;r<R;r++)for(let c=0;c<C;c++){const x=x0+c*CEL,y=y0+r*CEL;
    o+=`<rect x="${x}" y="${y}" width="${CEL}" height="${CEL}" fill="#fff" stroke="#000" stroke-width=".35"/>`;
    o+=`<svg x="${x+(CEL-it)/2}" y="${y+(CEL-it)/2}" width="${it}" height="${it}" viewBox="0 0 100 100">${W.dibuixa(B,T[r*C+c])}</svg>`;}
  o+=`<rect x="${x0}" y="${y0}" width="${w}" height="${h}" fill="none" stroke="#000" stroke-width=".8"/></svg>`;return o;}
/* ---------- plantilla ---------- */
/* Dos models: 'un' = un sol forat gran (per defecte: no té cap part fràgil); 'barres' = quatre forats separats per barres.
   Una sola plantilla per full A4 vertical i, al model d'un sol forat, com es fa la finestra plegant el paper (comu/plantilla.js, comu/plec.js). */
const plantillaSVG=model=>PLANTILLA.pagina(2,2,{model});
const plantillaLaser=model=>PLANTILLA.laser(2,2,{model});
/* ---------- solucionari ---------- */
const FLETXA=['↖','↗','↙','↘'];
function soluHTML(id){const [code]=id.split('-'),B=BANCS[code],T=tauler(id),[R,C]=W.dims(B);
  let o=`<div class="solu"><div class="cap"><span class="codi">${esc(id)}</span><span class="nota">Motius garantits. N'hi pot haver d'altres: qualsevol argument correcte val.</span></div><table>`;
  for(const [r,c] of W.wins(B)){const ids=W.cellsOf(B,r,c).map(i=>T[i]);o+=`<tr><td class="pos">${'ABCDEFGH'[r]}${c+1}</td>`;
    for(let k=0;k<4;k++){const et=W.etiqueta(B,ids[k]);o+=`<td><span class="el">${esc(et!=null?et:FLETXA[k])}</span> ${esc(W.motiuCurt(B,ids,k)||'—')}</td>`;}
    o+='</tr>';}
  return o+'</table></div>';}
/* ---------- pintar ---------- */
function idActual(){return st.banc+'-'+st.ver;}
function pinta(){const P=$('#pagines');let h='';
  $('#mida-pagina').textContent=st.vista==='plantilla'?'@page{size:A4 portrait;margin:0}':'@page{size:A4 landscape;margin:0}';
  if(st.vista==='full'){if(!tauler(idActual())){P.innerHTML='';return;}h=`<div class="pagina h">${fullSVG(idActual())}</div>`;}
  else if(st.vista==='plantilla')h=`<div class="pagina v">${plantillaSVG(st.model)}</div>`;
  else{const gen=[...st.solu].filter(x=>generats[x]),L=[];   // una cara per tema (fulls A–D); els fulls generats, de 4 en 4
    for(const c of ORDRE)if(st.solu.has(c))L.push(FIXOS(c).map(v=>c+'-'+v));
    for(let i=0;i<gen.length;i+=4)L.push(gen.slice(i,i+4));
    for(const g of L){h+='<div class="pagina h"><div class="solus">';for(let i=0;i<4;i++)h+=g[i]?soluHTML(g[i]):'<div class="solu"></div>';h+='</div></div>';}
    if(!L.length)h='<p>Tria almenys un tema.</p>';}
  P.innerHTML=h;escala();pintaSolu();pintaModel();}
function escala(){const pw=document.querySelector('.pagina');if(!pw)return;const mm=pw.classList.contains('v')?210:297;const px=mm*96/25.4;
  const z=Math.min(1,(document.documentElement.clientWidth-28)/px);document.querySelectorAll('.pagina').forEach(p=>p.style.setProperty('--z',z));}
function pintaSolu(){const box=$('#soluTria');box.classList.toggle('amagat',st.vista!=='solu');if(st.vista!=='solu')return;
  const tots=[...ORDRE,...Object.keys(generats)];
  box.innerHTML='<span>Solucionaris (una cara per tema, amb els fulls A–D; imprimeix a doble cara):</span>'+tots.map(id=>`<label><input type="checkbox" value="${id}" ${st.solu.has(id)?'checked':''}> ${id}</label>`).join('');
  box.querySelectorAll('input').forEach(i=>i.onchange=()=>{i.checked?st.solu.add(i.value):st.solu.delete(i.value);pinta();});}
function pintaModel(){const box=$('#modelTria');box.classList.toggle('amagat',st.vista!=='plantilla');
  box.querySelectorAll('button').forEach(b=>{b.classList.toggle('on',b.dataset.model===st.model);b.onclick=()=>{st.model=b.dataset.model;pinta();actualitzaHash();};});}
function estat(t){$('#estat').textContent=t||'';}
function actualitzaHash(){history.replaceState(null,'','#'+idActual()+(st.vista!=='full'?'/'+st.vista+(st.vista==='plantilla'&&st.model==='barres'?'-barres':''):''));}
function genera(num){const B=BANCS[st.banc],id=st.banc+'-'+num;
  if(generats[id]){st.ver=String(num);st.solu.add(id);marca();pinta();actualitzaHash();return;}
  estat('Generant el full '+id+'… (pot trigar uns segons)');$('#btnGen').disabled=true;
  setTimeout(()=>{const T=W.genera(B,num);$('#btnGen').disabled=false;
    if(!T){estat('No he trobat cap full vàlid amb el número '+num+'. Prova un altre número.');return;}
    generats[id]=T;st.solu.add(id);st.ver=String(num);estat('Full '+id+' generat. Amb el mateix número sempre surt el mateix full.');marca();pinta();actualitzaHash();},30);}
function marca(){$('#vers').innerHTML=FIXOS(st.banc).map(v=>`<button data-ver="${v}" class="${st.ver===v?'on':''}">${v}</button>`).join('');
  $('#vers').querySelectorAll('button').forEach(b=>b.onclick=()=>{st.ver=b.dataset.ver;estat('');marca();pinta();actualitzaHash();});
  document.querySelectorAll('[data-vista]').forEach(b=>b.classList.toggle('on',b.dataset.vista===st.vista));
  $('#banc').value=st.banc;if(/^\d+$/.test(st.ver))$('#num').value=st.ver;}
/* ---------- inici ---------- */
$('#banc').innerHTML=ORDRE.map(c=>`<option value="${c}">${c} · ${esc(BANCS[c].nom)}</option>`).join('');
$('#banc').onchange=e=>{st.banc=e.target.value;st.ver='A';estat('');marca();pinta();actualitzaHash();};
$('#btnGen').onclick=()=>{const n=parseInt($('#num').value,10);if(!(n>=1000&&n<=9999)){estat('Escriu un número entre 1000 i 9999.');return;}genera(n);};
$('#btnAtzar').onclick=()=>{const n=1000+Math.floor(Math.random()*9000);$('#num').value=n;genera(n);};
document.querySelectorAll('[data-vista]').forEach(b=>b.onclick=()=>{st.vista=b.dataset.vista;marca();pinta();actualitzaHash();});
$('#btnPrint').onclick=()=>window.print();
window.addEventListener('resize',escala);
window.addEventListener('beforeprint',()=>document.querySelectorAll('.pagina').forEach(p=>p.style.setProperty('--z',1)));
window.addEventListener('afterprint',escala);
function aplicaHash(){const m=/^#([A-Z0-9]{3})-([A-Z]|\d{4})(?:\/(full|plantilla|plantilla-barres|solu))?$/.exec(location.hash);
  if(m&&BANCS[m[1]]&&(/\d/.test(m[2])||BANCS[m[1]].fulls[m[2]])){st.banc=m[1];st.vista=(m[3]||'full').replace('-barres','');st.model=m[3]==='plantilla-barres'?'barres':'un';if(BANCS[m[1]].fulls[m[2]]){st.ver=m[2];marca();pinta();}else{marca();genera(+m[2]);}}else{marca();pinta();}}
window.addEventListener('hashchange',aplicaHash);aplicaHash();
window.__reixeta={fullSVG,plantillaLaser,soluHTML,generats,st,pinta};
})();
